from django.contrib import admin

# Register your models here.
from goods.models import GoodsSKU

admin.site.register(GoodsSKU)

